#ifndef _LISTA_H_
#define _LISTA_H_

#include "Nodo.h"

template <class tipo_lista>
class Lista{

	private:

		Nodo<tipo_lista>* primero;
		int tamanio;

	public:

		Lista();
	
		int obtener_tamanio();	


};

template <class tipo_lista>
Lista<tipo_lista>::Lista(){
}

template <class tipo_lista>
int Lista<tipo_lista>::obtener_tamanio(){
	return tamanio;
}



#endif