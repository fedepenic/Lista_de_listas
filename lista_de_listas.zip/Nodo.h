#ifndef _NODO_H_
#define _NODO_H_

template <class tipo_de_dato>
class Nodo{

	private:

		tipo_de_dato dato;
		Nodo<tipo_de_dato>* p_sig;

	public:

		Nodo();	

		tipo_de_dato obtener_dato();

		Nodo<tipo_de_dato>* obtener_siguiente();

		void asignar_dato(tipo_de_dato nuevo_dato);

		void asignar_siguiente(Nodo<tipo_de_dato>* siguiente);
};

template <class tipo_de_dato>
Nodo<tipo_de_dato>::Nodo(){
	dato = 0;
	p_sig = NULL;
}

template <class tipo_de_dato>
tipo_de_dato Nodo<tipo_de_dato>::obtener_dato(){
	return dato;
} 

template <class tipo_de_dato>
Nodo<tipo_de_dato>* Nodo<tipo_de_dato>::obtener_siguiente(){
	return p_sig;
}

template <class tipo_de_dato>
void Nodo<tipo_de_dato>::asignar_dato(tipo_de_dato nuevo_dato){
	dato = nuevo_dato;
}

template <class tipo_de_dato>
void Nodo<tipo_de_dato>::asignar_siguiente(Nodo<tipo_de_dato>* siguiente){
	p_sig = siguiente;
}

#endif 