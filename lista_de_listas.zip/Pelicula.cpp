#include "Pelicula.h"

using namespace std;

Pelicula::Pelicula(){
}

string Pelicula::obtener_nombre(){
	return nombre;
}

string Pelicula::obtener_genero(){
	return genero;
}

string Pelicula::obtener_director(){
	return director;
}

int Pelicula::obtener_puntaje(){
	return puntaje;
}

void Pelicula::asignar_nombre(string nuevo_nombre){
	nombre = nuevo_nombre;
}

void Pelicula::asignar_genero(string nuevo_genero){
	genero = nuevo_genero;
}

void Pelicula::asignar_director(string nuevo_director){
	director = nuevo_director;
}

void Pelicula::asignar_puntaje(int nuevo_puntaje){
	puntaje = nuevo_puntaje;
}