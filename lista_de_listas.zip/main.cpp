#include "Pelicula.h"
#include "Nodo.h"
#include "Lista.h"

using namespace std;

int main(){


	return 0;
}